package com.vestris.vmwarecomlib  ;

import com4j.*;

@IID("{1C695993-B464-3534-AC57-2430922DF19D}")
public interface _VariableIndexer extends Com4jObject {
}
