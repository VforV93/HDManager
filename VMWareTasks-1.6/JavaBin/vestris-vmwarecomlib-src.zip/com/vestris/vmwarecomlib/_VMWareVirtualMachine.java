package com.vestris.vmwarecomlib  ;

import com4j.*;

@IID("{E8B28CEF-E395-3D72-B170-8F750DE35F63}")
public interface _VMWareVirtualMachine extends Com4jObject {
}
