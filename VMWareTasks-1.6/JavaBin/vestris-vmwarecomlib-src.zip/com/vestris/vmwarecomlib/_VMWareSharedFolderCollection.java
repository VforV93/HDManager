package com.vestris.vmwarecomlib  ;

import com4j.*;

@IID("{5859B00A-54D2-3707-8B22-26D7405BBD8B}")
public interface _VMWareSharedFolderCollection extends Com4jObject {
}
