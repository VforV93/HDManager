package com.vestris.vmwarecomlib  ;

import com4j.*;

@IID("{01D79AF5-AAB1-350A-B34D-0FF075632856}")
public interface _Process extends Com4jObject {
}
