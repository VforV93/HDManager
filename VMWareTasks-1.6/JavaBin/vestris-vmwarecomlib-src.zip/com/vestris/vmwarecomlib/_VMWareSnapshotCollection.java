package com.vestris.vmwarecomlib  ;

import com4j.*;

@IID("{FC31C8CA-95CE-3876-A7EF-B48C2B9DE11B}")
public interface _VMWareSnapshotCollection extends Com4jObject {
}
