package com.vestris.vmwarecomlib  ;

import com4j.*;

@IID("{76B0E3D2-0D03-369C-B1CB-CFAA927FC5A7}")
public interface _VMWareVirtualHost extends Com4jObject {
}
