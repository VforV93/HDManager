package com.vestris.vmwarecomtools  ;

import com4j.*;

@IID("{83E6DF91-BDDC-30AB-9EE0-499E850A0572}")
public interface _VMWareSnapshot extends Com4jObject {
}
