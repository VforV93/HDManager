package com.vestris.vmwarecomtools  ;

import com4j.*;

@IID("{CC5CC05C-F9F5-3C66-9405-8B757D2D7390}")
public interface _GuestFileInfo extends Com4jObject {
}
