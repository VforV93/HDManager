package com.vestris.vmwarecomtools  ;

import com4j.*;

@IID("{BCE5D20C-782F-3524-B8B3-B56AFF2FC13A}")
public interface _Shell extends Com4jObject {
}
