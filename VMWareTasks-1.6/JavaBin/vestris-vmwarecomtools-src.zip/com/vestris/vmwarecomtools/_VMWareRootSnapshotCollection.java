package com.vestris.vmwarecomtools  ;

import com4j.*;

@IID("{6142DF85-7670-3E23-BD0C-C85D71C444A6}")
public interface _VMWareRootSnapshotCollection extends Com4jObject {
}
